import telebot

TOKEN = "7915572545:AAHaNec6Hw4LyFRbBZTTH1ahBJK-fhyhafg"
BOT_USERNAME = "abdulla_birnimabot"

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(func=lambda message: True)
def handle_message(message):
    if message.chat.type in ["group", "supergroup"]:
        # Etiketlenmiş mi?
        if f"@{BOT_USERNAME}" in message.text:
            bot.reply_to(message, "Assalomu alaykum, qanday yordam kerak? 🫡")

bot.infinity_polling()





import telebot

bot = telebot.TeleBot("7915572545:AAHaNec6Hw4LyFRbBZTTH1ahBJK-fhyhafg")

welcome_message = """👋 *Assalomu alaykum!*  
Anime Chat Zero'ga xush kelibsiz.  
👤 EGA: @h571NABI

📜 Guruh qoidalari:
1️⃣ Soʻkinmaslik ✈️
2️⃣ Haqoratlarsiz suhbat 🎇
3️⃣ Reklama qilmaslik (post ham) ✈️
4️⃣ Qoidalarni buzmaslik 🚀
"""

@bot.message_handler(content_types=['new_chat_members'])
def welcome_new_member(message):
    for new_member in message.new_chat_members:
        bot.send_message(
            message.chat.id,
            f"👋 Assalomu alaykum, [{new_member.first_name}](tg://user?id={new_member.id})!\n\n{welcome_message}",
            parse_mode="Markdown"
        )

bot.polling()




from telebot import TeleBot, types

TOKEN = "7915572545:AAHaNec6Hw4LyFRbBZTTH1ahBJK-fhyhafg"
bot = TeleBot(TOKEN)

@bot.message_handler(commands=['ban'])
def ban_user(message):
    if not message.reply_to_message:
        bot.reply_to(message, "Banlamak için birine cevap ver.")
        return
    try:
        user_id = message.reply_to_message.from_user.id
        bot.ban_chat_member(message.chat.id, user_id)
        bot.reply_to(message, f"🚫 {message.reply_to_message.from_user.first_name} gruptan banlandı.")
    except Exception as e:
        bot.reply_to(message, f"Banlanamadı: {e}")

@bot.message_handler(commands=['mute'])
def mute_user(message):
    if not message.reply_to_message:
        bot.reply_to(message, "Mute atmak için birine cevap ver.")
        return
    try:
        user_id = message.reply_to_message.from_user.id
        until_date = types.ChatPermissions(can_send_messages=False)
        bot.restrict_chat_member(message.chat.id, user_id, permissions=until_date)
        bot.reply_to(message, f"🔇 {message.reply_to_message.from_user.first_name} susturuldu.")
    except Exception as e:
        bot.reply_to(message, f"Mute atılamadı: {e}")

@bot.message_handler(commands=['unmute'])
def unmute_user(message):
    if not message.reply_to_message:
        bot.reply_to(message, "Unmute atmak için birine cevap ver.")
        return
    try:
        user_id = message.reply_to_message.from_user.id
        allow_all = types.ChatPermissions(can_send_messages=True,
                                          can_send_media_messages=True,
                                          can_send_polls=True,
                                          can_send_other_messages=True,
                                          can_add_web_page_previews=True,
                                          can_change_info=True,
                                          can_invite_users=True,
                                          can_pin_messages=True)
        bot.restrict_chat_member(message.chat.id, user_id, permissions=allow_all)
        bot.reply_to(message, f"🔊 {message.reply_to_message.from_user.first_name} artık konuşabilir.")
    except Exception as e:
        bot.reply_to(message, f"Unmute atılamadı: {e}")

print("Bot çalışıyor...")
bot.infinity_polling()








import telebot
from telebot.types import ChatPermissions
from datetime import timedelta, datetime

TOKEN = "7915572545:AAHaNec6Hw4LyFRbBZTTH1ahBJK-fhyhafg"
bot = telebot.TeleBot(TOKEN)

RULES = """👋 Assalomu alaykum va guruhga hush kelibsiz!
📜 *Guruh qoidalari:*
1️⃣ Soʻkinmaslik ✈️
2️⃣ Haqoratlarsiz suhbat 🎇
3️⃣ Reklama qilmaslik (post ham) ✈️
4️⃣ Qoidalarni buzmaslik 🚀
ega @h571NABI
"""

# Gruba yeni biri gelirse
@bot.message_handler(content_types=['new_chat_members'])
def welcome_new_member(message):
    for user in message.new_chat_members:
        bot.reply_to(message, f"👋 Assalomu alaykum {user.first_name}, AnimeChat Zeroga hush kelibsiz!\n\n{RULES}")

# Bot etikette çağırılırsa
@bot.message_handler(func=lambda m: bot.get_me().username in m.text)
def mentioned(message):
    bot.reply_to(message, f"👋 Assalomu alaykum {message.from_user.first_name}, yaxshimisiz?")

# /ban komutu
@bot.message_handler(commands=['ban'])
def ban_user(message):
    if not message.reply_to_message:
        bot.reply_to(message, "Kimni ban qilay? Avval uni reply qilib /ban yozing.")
        return
    bot.kick_chat_member(message.chat.id, message.reply_to_message.from_user.id)
    bot.reply_to(message, f"✅ {message.reply_to_message.from_user.first_name} ban qilindi.")

# /unban komutu
@bot.message_handler(commands=['unban'])
def unban_user(message):
    if not message.reply_to_message:
        bot.reply_to(message, "Kimni unban qilay? Avval uni reply qilib /unban yozing.")
        return
    bot.unban_chat_member(message.chat.id, message.reply_to_message.from_user.id)
    bot.reply_to(message, f"✅ {message.reply_to_message.from_user.first_name} unban qilindi.")

# /mute komutu
@bot.message_handler(commands=['mute'])
def mute_user(message):
    if not message.reply_to_message:
        bot.reply_to(message, "Kimni mute qilay? Avval uni reply qilib /mute 5m kabi yozing.")
        return
    try:
        parts = message.text.split()
        duration_str = parts[2] if len(parts) > 2 else '5m'
        minutes = int(duration_str.rstrip('m'))
        until_date = datetime.utcnow() + timedelta(minutes=minutes)
        permissions = ChatPermissions(can_send_messages=False)
        bot.restrict_chat_member(message.chat.id, message.reply_to_message.from_user.id, permissions, until_date=until_date)
        bot.reply_to(message, f"🔇 {message.reply_to_message.from_user.first_name} {minutes} daqiqaga mute qilindi.")
    except:
        bot.reply_to(message, "Xatolik: /mute @kisi 5m kabi foydalaning.")

# /unmute komutu
@bot.message_handler(commands=['unmute'])
def unmute_user(message):
    if not message.reply_to_message:
        bot.reply_to(message, "Kimni unmute qilay? Avval uni reply qilib /unmute yozing.")
        return
    permissions = ChatPermissions(can_send_messages=True,
                                  can_send_media_messages=True,
                                  can_send_other_messages=True,
                                  can_add_web_page_previews=True)
    bot.restrict_chat_member(message.chat.id, message.reply_to_message.from_user.id, permissions)
    bot.reply_to(message, f"🔊 {message.reply_to_message.from_user.first_name} unmute qilindi.")

# Her zaman aktif tut
print("🤖 Bot ishga tushdi va ishlayapti!")
bot.infinity_polling()





